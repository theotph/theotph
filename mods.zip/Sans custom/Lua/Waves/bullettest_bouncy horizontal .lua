spawntimer = 0
bullets = {}

function Update()

	spawntimer = spawntimer + 1
	
	if spawntimer%60 == 0 then
		for i = 1,3 do
			local spawny = -Arena.width/2 + Arena.width/4 * i
			local spawnx = Arena.height/2
			local bullet2 = CreateProjectile( 'bullet2' , spawnx , spawny )
			table.insert(bullets,bullet2)
		end
	end
	
	for i = 1 , #bullets do
		local bullet2 = bullets[i]
		if bullet2.isactive then
			bullet2.Move( -1 , 0 )
			if bullet2.absy < -15 then bullet.Remove() end
		end
	end
	
end