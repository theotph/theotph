spawntimer = 0
bullets = {}

function Update()

	spawntimer = spawntimer + 1
	
	if spawntimer%15 == 0 then
		for i = 1,12 do
			local spawnx = -Arena.width/2 + Arena.width/13 * i
			local spawny = Arena.height/2
			local bulletDT = CreateProjectile( 'bulletDT' , spawnx , spawny )
			table.insert(bullets,bulletDT)
		end
	end
	
	for i = 1 , #bullets do
		local bulletDT = bullets[i]
		if bulletDT.isactive then
			bulletDT.Move( 0 , -2 )
			if bulletDT.y < -45 then bulletDT.Remove() end
		end
	end
	
end
function OnHit(bulletDT )
    if  Player.hp < 94 then
        Player.Hurt(20)
    elseif   Player.hp > 95 then
        Player.Hurt(50)
    end
end