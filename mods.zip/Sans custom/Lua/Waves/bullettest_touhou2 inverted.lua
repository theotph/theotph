spawntimer = 0
bullets = {}

function Update()

	spawntimer = spawntimer + 1
	
	if spawntimer%30 == 0 then
		for i = 1,5 do
			local bullet4 = CreateProjectile( 'bullet4' , Arena.height/3, -Arena.width/5 + Arena.width/6 * i)
			table.insert(bullets,bullet4)
		end
	end
	
	for i = 1 , #bullets do
		local bullet4 = bullets[i]
		if bullet4.isactive then
			bullet4.Move( -1 , -1 )
			if bullet4.absy < -15 then bullet4.Remove() end
		end
	end
	
end
