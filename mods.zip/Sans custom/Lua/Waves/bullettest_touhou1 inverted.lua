spawntimer = 0
bullets = {}

function Update()

	spawntimer = spawntimer + 1
	
	if spawntimer%30 == 0 then
		for i = 1,5 do
			local bullet3 = CreateProjectile( 'bullet3' , Arena.height/-3, -Arena.width/5 + Arena.width/6 * i)
			table.insert(bullets,bullet3)
		end
	end
	
	for i = 1 , #bullets do
		local bullet3 = bullets[i]
		if bullet3.isactive then
			bullet3.Move( 1 , -1 )
			if bullet3.absy < -15 then bullet3.Remove() end
		end
	end
	
end
