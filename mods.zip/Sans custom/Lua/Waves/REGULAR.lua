bullets = {}
bullets = {}

rot_speed = 1
vel = 0.2
R = Arena.width/2
start_angle = 0

midx = 0
midy = Arena.width/2 + Arena.height/2

for i = 1, 12 do
	local angle = start_angle + 360 / 12 * i
	local rangle = math.rad(angle)
	local spawnx = math.cos(rangle) * R
	local spawny = math.sin(rangle) * R
	local bullet1 = CreateProjectile( 'bullet1' , spawnx , spawny )
	bullet1.SetVar('angle',angle)
	table.insert(bullets,bullet1)
end

function Update()
	for i = 1 , #bullets do
		local bullet1 = bullets[i]
		local angle = bullet1.GetVar('angle')
		angle = angle + rot_speed
		local rangle = math.rad(angle)
		local newposx = math.cos(rangle) * R + midx
		local newposy = math.sin(rangle) * R + midy
		bullet1.MoveTo( newposx , newposy )
		bullet1.SetVar('angle',angle)
		midy = midy - vel
	end
end