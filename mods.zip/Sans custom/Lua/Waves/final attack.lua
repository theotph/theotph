spawntimer = 0
bullets = {}
Arena.Resize(20, 20)

rot_speed = 0.1
velR = 1.5

function Update()
	spawntimer = spawntimer + 1
	if spawntimer%100 == 0 then
		local start_angle = 360
		for i = 1, 120 do
			local R = 200
			local angle = start_angle + 300 / 100 * i
			local rangle = math.rad(angle)
			local spawnx = math.cos(rangle) * R
			local spawny = math.sin(rangle) * R
			local bullet1 = CreateProjectile( 'bullet1' , spawnx , spawny )
			bullet1.SetVar('R',R)
			bullet1.SetVar('angle',angle)
			table.insert(bullets,bullet1)
		end
	end
	for i = 1 , #bullets do
		local bullet1 = bullets[i]
		if bullet1.isactive then
			local R = bullet1.GetVar('R')
			local angle = bullet1.GetVar('angle')
			angle = angle + rot_speed
			R = R - velR
			local rangle = math.rad(angle)
			local newposx = math.cos(rangle) * R
			local newposy = math.sin(rangle) * R
			bullet1.MoveTo( newposx , newposy )
			bullet1.SetVar('angle',angle)
			bullet1.SetVar('R',R)
			
			if R <= 0 then bullet1.Remove() end
			
		end
	end
end
function OnHit(bullet1)
    if  Player.hp < 99 then
        Player.hp = 1
    end
end