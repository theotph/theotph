spawntimer = 0
bullets = {}

function Update()

	spawntimer = spawntimer + 1
	
	if spawntimer%30 == 0 then
		for i = 1,4 do
			local spawnx = -Arena.width/2 + Arena.width/5 * i
			local spawny = Arena.height/2
			local bullet1 = CreateProjectile( 'bullet1' , spawnx , spawny )
			table.insert(bullets,bullet1)
		end
	end
	
	for i = 1 , #bullets do
		local bullet1 = bullets[i]
		if bullet1.isactive then
			bullet1.Move( 0 , -1 )
			if bullet1.absy < -15 then bullet1.Remove() end
		end
	end
	
end