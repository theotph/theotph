-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"EAT HIM LOL", "KILL HIM.", "STAB HIM"}
commands = {"DETERMINATION", "KIDNESS", "Act 3"}
randomdialogue = {"Random\nDialogue\n1.", "Random\nDialogue\n2.", "Random\nDialogue\n3."}

sprite = "poseur" --Always PNG. Extension is added automatically.
name = "Sans"
hp = 1000000
atk = 10
def = 1
check = "hello FRISK."
dialogbubble = "right" -- See documentation for what bubbles you have available.
canspare = false
cancheck = true

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack
    end
end
 
-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if command == "DETERMINATION" then
        currentdialogue = {"Selected\nAct 1."}
        if Player.hp < 2 then
        Player.atk = 999999 end
    elseif command == "KIDNESS" then
        currentdialogue = {"Selected\nAct 2."}
        Player.Heal(99)
    elseif command == "ACT 3" then
        currentdialogue = {"Selected\nAct 3."}
    end
    BattleDialog({"You selected " .. command .. "."})
end