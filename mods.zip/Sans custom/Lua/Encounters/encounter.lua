-- A basic encounter script skeleton you can copy and modify for your own creations.

 music = "Megalovania" --Either OGG or WAV. Extension is added automatically. Uncomment for custom music.
encountertext = "Poseur strikes a pose!" --Modify as necessary. It will only be read out in the action select screen.
nextwaves = {}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"poseur"
}

enemypositions = {
{0, 0}
}

attacknum = 0
-- A custom list with attacks to choose from. Actual selection happens in EnemyDialogueEnding(). Put here in case you want to use it.
possible_attacks = {"bullettest_chaserorb"}

function EncounterStarting()
    -- If you want to change the game state immediately, this is the place.
    Player.lv = 20
    Player.hp = 99
    Player.name = "frisk"
end

function EnemyDialogueStarting()
    -- Good location for setting monster dialogue depending on how the battle is going.
    enemies[1].SetVar('currentdialogue', {"Litle bitch"})
    enemies[1].SetVar('currentdialogue', {"GO TO HELL"})
end

function EnemyDialogueEnding()
    attacknum = attacknum + 1
    if attacknum == 1 then
       nextwaves = {"bullettest_bouncy", "bullettest_chaserorb", "bullettest_touhou1", "bullettest_touhou2"}
    elseif attacknum == 2 then
       nextwaves = {"REGULAR"}
    elseif attacknum == 3 then
       nextwaves = {"bone shower"}
    elseif attacknum == 4 then
       nextwaves = {"bullettest_bouncy inverted", "bullettest_chaserorb inverted", "bullettest_touhou1 inverted", "bullettest_touhou2 inverted"}
    elseif attacknum == 5 then
       nextwaves = {"final attack"}
    end
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
end

function HandleSpare()
    State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end

function HandleSpare()
    State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end